<?php
ob_start();
session_start();
require "DB_conn.php";

if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['subject']) && isset($_POST['message'])){
	if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['subject']) && !empty($_POST['message'])){

		$to = "nss.vce.hyd@gmail.com";
		$subject = $_POST['subject'];
		$txt = $_POST['message'];
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers = "From: ".$_POST['email']. "\r\n";

		if(mail($to,$subject,$txt,$headers)){
			echo '<script language="javascript">';
			echo 'alert("Success")';
			echo '</script>';
		}else{
			echo '<script language="javascript">';
			echo 'alert("Failed")';
			echo '</script>';
		}
	}
}

?>


<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css/main2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script type="text/javascript" src="js/script.js"></script>

</head>
<body>

<div class="col-12" style="height: 350px;">
	<div id="comname">
		<i  aria-hidden="true"></i><br><br><b>BBMS</b>
	</div>
	<div id="nav" class="col-12">
		<ul>
		  <li><a href="index.php">Home</a></li>
		  <li><a href="about.php">About</a></li>
		  <li><a class="active" href="contact.php">Contact</a></li>
		  <li><a href="register.php">Be A Donor</a></li>
		  <li><a href="change_details.php">Change Details</a></li>
		  <li><a href="aadhaar.html">Find Donor</a></li>
		  <?php 
		  	if(isset($_SESSION['sess_user_id'])&&!empty($_SESSION['sess_user_id'])){
				echo '<li style="background-color: rgba(255,0,0,0.5);"><a href="logout.php">Logout</a></ul>';
			}
		  ?>
		</ul>
	</div>
	<span class="info2" style="left: 40%">CONTACT</span>
	<img class="myFrontPic col-12" src="images/5.jpg" style="height: 350px;">
</div>
<br>
<div>
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3807.650802848768!2d78.38042561487626!3d17.38052818808275!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb942a2497f349%3A0x5c30ca8d2ffb8734!2sVasavi%20College%20of%20Engineering!5e0!3m2!1sen!2sin!4v1586087941785!5m2!1sen!2sin" width="1450" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
</div>
	<div style="margin: 0; padding: 0; text-align: center; overflow: auto;">
		<div class="col-6" style="float: left; text-align: left; padding: 5%; background-color: rgb(217, 219, 224);">
		<h1 style="color: blue;">SUGGESTION</h1>
			<form action="contact.php" method="post">
				Name(required)<span style="color: red;">*</span><br>
				<input class="in" type="text" name="name" placeholder="Enter Name" required style=""><br><br>
				Email(required)<span style="color: red;">*</span><br>
				<input class="in" type="text" name="email" placeholder="Enter Your Email" required><br><br>
				Subject(required)<span style="color: red;">*</span><br>
				<input class="in" type="text" name="subject" placeholder="Enter Subject"><br><br>
				Message(required)<span style="color: red;">*</span><br>
				<textarea class="in" name="message" placeholder="Type your message" style="height: 300px;"></textarea><br><br>
				<input class="qw" style="font-size: 16px; color: white;" type="submit" value="SEND">
			</form>
		</div>
		
		<br>
		
		

		<div class="col-3" style="width: 15%;float: right; background-color: rgb(217, 219, 224); overflow: auto; text-align: left; margin: 0 3% 3% 3%">
			<h1 align="center" style="color: rgb(76, 109, 86); font-size: 20px;margin: 5%;">CONTACT</h1>
			<div align="center" style="height: 120px; width: 120px;margin: 5%;margin-left: 20%"><img class="im" src="nss.jpg"></div>
			
			<p align="center" style="color: rgb(76, 109, 86); font-size: 20px;margin: 5%;">NSS</p>
			<p align="center" style="color: rgb(76, 109, 86); font-size: 20px;margin: 5%;">8686382248</p>
		</div>
	</div>


<div id="footer" class="col-12" style="margin: 0; padding: 0;overflow: auto;">
	<?php include "footer.php"; ?>
</div>

</body>


</html>