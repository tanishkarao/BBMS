# Blood-Donation-Management-system
* This is a simple blood donation management system.
* When there is need of blood, we have to select blood group that we need, it will show the list of blood donors(persons who have registered on website to donate blood) with their details.
* A person has to register on website if he wants to donate blood.
